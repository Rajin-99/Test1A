package com.example.login;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
public class HelloController {
    public Label Message;
    private int failedAttempts = 1;


    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;


    @FXML
    protected void handleLoginButtonAction() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        if (failedAttempts >= 5) {
            Message.setText("Sorry, Your Account is Locked!!!");
            return;
        }

        if (username.isEmpty() || password.isEmpty()) {
            Message.setText("Enter the  Username or Password");
        } else if (username.equals("Rajin") && password.equals("357")) {
            Message.setText("Congratulations! you are successfully logged in.");
            failedAttempts = 0;
        } else {
            Message.setText(" Sorry! Invalid Username or Password");
            failedAttempts++;
        }
    }
}